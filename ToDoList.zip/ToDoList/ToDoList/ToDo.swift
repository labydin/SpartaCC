//
//  ToDo.swift
//  ToDoList
//
//  Created by 박준영 on 3/21/24.
//

import UIKit


struct ToDo {
    var id: Int
    var title: String
    var isCompleted: Bool
}
